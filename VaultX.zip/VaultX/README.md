# VaultX – Neumorphic Password Manager for Android

Offline password manager with **automatic save + autofill** in any app or browser, and a soft **neumorphism** UI (light & dark).

## Features
- **Auto-save** – sign in to any app or website and Android asks *“Save to VaultX?”*. Changed passwords are updated automatically.
- **Autofill** – VaultX suggestions appear above login fields; tapping one asks for fingerprint / face / screen lock, then fills username + password.
- **Manual entry** – add, edit, delete, search, copy (clipboard auto-clears after 30 s).
- **Password generator** – length 8–48, uppercase / numbers / symbols, strength meter.
- **Security health** – score with weak and reused password counts.
- **Security** – AES-256-GCM encryption with a key in the Android Keystore, biometric/device-lock unlock, auto-lock, screenshots blocked, no internet permission, no cloud backup.

## Build with GitHub Actions
1. Unzip, then push everything to a new GitHub repo (keep the `.github` folder).
2. Open the **Actions** tab → *Build VaultX (APK + AAB)* runs automatically on every push.
3. Download **VaultX-APK** (install on phone) and **VaultX-AAB** (upload to Play Store) from the run's *Artifacts*.
4. Push a tag like `v1.0.0` to also get a GitHub Release with both files attached.

### Permanent signing key (recommended)
Without secrets the workflow signs with a temporary key, so each new build can't install over the old one. Create a key once:
```bash
keytool -genkeypair -v -keystore vaultx.jks -alias vaultx -keyalg RSA -keysize 2048 -validity 10000
base64 -w 0 vaultx.jks > vaultx.b64
```
Add these in **Settings → Secrets and variables → Actions**: `KEYSTORE_BASE64` (content of vaultx.b64), `KEYSTORE_PASSWORD`, `KEY_ALIAS` (vaultx), `KEY_PASSWORD`. Keep the `.jks` file safe – Play Store updates need it forever.

## First run on the phone
1. Open VaultX → **Enable autofill** → choose VaultX as the autofill service.
2. Chrome: Settings → *Autofill services* → *Autofill using another service* → restart Chrome.
3. Log in anywhere – VaultX offers to save it. Next time, tap the VaultX suggestion to fill.

## Matching rules
- Apps are matched by exact package name (e.g. `com.instagram.android`) so a look-alike app never receives another app's login.
- Websites match the domain and its sub-domains (`google.com` ↔ `accounts.google.com`).

## Tech
Kotlin · Jetpack Compose · Material 3 · Android Autofill Framework · AndroidX Biometric · minSdk 26 / targetSdk 34 · AGP 8.5 · Gradle 8.9 · JDK 17

Open the folder in Android Studio to run locally.
