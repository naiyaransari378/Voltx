package com.vaultx.app.autofill

import android.app.PendingIntent
import android.content.Intent
import android.content.IntentSender
import android.os.Build
import android.os.CancellationSignal
import android.service.autofill.AutofillService
import android.service.autofill.Dataset
import android.service.autofill.FillCallback
import android.service.autofill.FillRequest
import android.service.autofill.FillResponse
import android.service.autofill.SaveCallback
import android.service.autofill.SaveInfo
import android.service.autofill.SaveRequest
import android.widget.RemoteViews
import android.widget.Toast
import com.vaultx.app.R
import com.vaultx.app.data.Credential
import com.vaultx.app.data.Prefs
import com.vaultx.app.data.SaveResult
import com.vaultx.app.data.Vault

class VaultAutofillService : AutofillService() {

    override fun onFillRequest(request: FillRequest, cancellationSignal: CancellationSignal, callback: FillCallback) {
        try {
            val structure = request.fillContexts.lastOrNull()?.structure
            if (structure == null) { callback.onSuccess(null); return }
            val parsed = StructureParser.parse(structure)
            if (parsed.packageName == packageName || parsed.ids.isEmpty()) { callback.onSuccess(null); return }

            Vault.init(this)
            val response = FillResponse.Builder()
            var hasContent = false

            Vault.matches(parsed.target, parsed.isWeb).take(MAX_DATASETS).forEach { cred ->
                response.addDataset(lockedDataset(cred, parsed))
                hasContent = true
            }

            val passwordId = parsed.passwordId
            if (Prefs.autoSave(this) && passwordId != null) {
                val usernameId = parsed.usernameId
                val type = if (usernameId != null) {
                    SaveInfo.SAVE_DATA_TYPE_PASSWORD or SaveInfo.SAVE_DATA_TYPE_USERNAME
                } else {
                    SaveInfo.SAVE_DATA_TYPE_PASSWORD
                }
                val saveInfo = SaveInfo.Builder(type, arrayOf(passwordId))
                if (usernameId != null) saveInfo.setOptionalIds(arrayOf(usernameId))
                saveInfo.setFlags(SaveInfo.FLAG_SAVE_ON_ALL_VIEWS_INVISIBLE)
                response.setSaveInfo(saveInfo.build())
                hasContent = true
            }

            callback.onSuccess(if (hasContent) response.build() else null)
        } catch (e: Exception) {
            callback.onSuccess(null)
        }
    }

    override fun onSaveRequest(request: SaveRequest, callback: SaveCallback) {
        try {
            var user: String? = null
            var pass: String? = null
            var target: String? = null
            var isWeb = false
            var pkg = ""
            for (ctx in request.fillContexts) {
                val p = StructureParser.parse(ctx.structure)
                if (!p.usernameValue.isNullOrBlank()) user = p.usernameValue
                if (!p.passwordValue.isNullOrBlank()) pass = p.passwordValue
                if (p.packageName.isNotBlank()) {
                    target = p.target; isWeb = p.isWeb; pkg = p.packageName
                }
            }
            val password = pass
            val tgt = target
            if (password.isNullOrBlank() || tgt.isNullOrBlank() || pkg == packageName) {
                callback.onSuccess(); return
            }
            Vault.init(this)
            val title = if (isWeb) Vault.normalize(tgt) else appLabel(pkg)
            when (Vault.saveFromAutofill(tgt, title, user.orEmpty(), password)) {
                SaveResult.CREATED -> toast(getString(R.string.saved_toast))
                SaveResult.UPDATED -> toast(getString(R.string.updated_toast))
                SaveResult.UNCHANGED -> Unit
            }
            callback.onSuccess()
        } catch (e: Exception) {
            callback.onFailure(e.message ?: "VaultX could not save this login")
        }
    }

    @Suppress("DEPRECATION")
    private fun lockedDataset(cred: Credential, parsed: ParsedFields): Dataset {
        val subtitle = cred.username.ifBlank { getString(R.string.autofill_locked_hint) }
        val builder = Dataset.Builder(presentation(cred.title, subtitle))
        // Values are released only after the user authenticates (see AutofillAuthActivity).
        parsed.usernameId?.let { builder.setValue(it, null) }
        parsed.passwordId?.let { builder.setValue(it, null) }
        builder.setAuthentication(authSender(cred, parsed))
        return builder.build()
    }

    private fun authSender(cred: Credential, parsed: ParsedFields): IntentSender {
        val intent = Intent(this, AutofillAuthActivity::class.java).apply {
            putExtra(AutofillAuthActivity.EXTRA_CRED_ID, cred.id)
            putExtra(AutofillAuthActivity.EXTRA_USER_ID, parsed.usernameId)
            putExtra(AutofillAuthActivity.EXTRA_PASS_ID, parsed.passwordId)
        }
        var flags = PendingIntent.FLAG_CANCEL_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) flags = flags or PendingIntent.FLAG_MUTABLE
        return PendingIntent.getActivity(this, cred.id.hashCode(), intent, flags).intentSender
    }

    private fun presentation(title: String, subtitle: String) =
        RemoteViews(packageName, R.layout.autofill_item).apply {
            setTextViewText(R.id.title, title)
            setTextViewText(R.id.subtitle, subtitle)
        }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        val parts = pkg.split('.')
        (parts.getOrNull(1) ?: pkg).replaceFirstChar { it.uppercase() }
    }

    private fun toast(msg: String) = Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()

    companion object {
        private const val MAX_DATASETS = 6
    }
}
