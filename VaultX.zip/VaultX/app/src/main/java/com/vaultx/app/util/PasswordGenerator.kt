package com.vaultx.app.util

import java.security.SecureRandom

object PasswordGenerator {
    private const val LOWER = "abcdefghijkmnopqrstuvwxyz"
    private const val UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ"
    private const val DIGITS = "23456789"
    private const val SYMBOLS = "!@#\$%^&*()-_=+[]{};:,.?"
    private val random = SecureRandom()

    fun generate(length: Int, upper: Boolean, digits: Boolean, symbols: Boolean): String {
        val sets = buildList {
            add(LOWER)
            if (upper) add(UPPER)
            if (digits) add(DIGITS)
            if (symbols) add(SYMBOLS)
        }
        val all = sets.joinToString("")
        val chars = sets.map { it[random.nextInt(it.length)] }.toMutableList()
        while (chars.size < length) chars += all[random.nextInt(all.length)]
        for (i in chars.indices.reversed()) {
            val j = random.nextInt(i + 1)
            val tmp = chars[i]; chars[i] = chars[j]; chars[j] = tmp
        }
        return chars.joinToString("")
    }

    /** 0 = very weak … 4 = excellent */
    fun strength(pw: String): Int {
        if (pw.isEmpty()) return 0
        var score = 0
        if (pw.length >= 8) score++
        if (pw.length >= 12) score++
        if (pw.length >= 16) score++
        val variety = listOf(
            pw.any { it.isLowerCase() }, pw.any { it.isUpperCase() },
            pw.any { it.isDigit() }, pw.any { !it.isLetterOrDigit() },
        ).count { it }
        if (variety >= 3) score++
        if (variety <= 1) score--
        return score.coerceIn(0, 4)
    }

    fun label(score: Int) = listOf("Very weak", "Weak", "Fair", "Strong", "Excellent")[score.coerceIn(0, 4)]
}
