package com.vaultx.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import java.io.File

enum class SaveResult { CREATED, UPDATED, UNCHANGED }

/** Encrypted, on-device credential store shared by the app UI and the autofill service. */
object Vault {
    private val _items = MutableStateFlow<List<Credential>>(emptyList())
    val items: StateFlow<List<Credential>> = _items.asStateFlow()
    private var file: File? = null

    @Synchronized
    fun init(context: Context) {
        if (file != null) return
        val f = File(context.applicationContext.filesDir, "vault.bin")
        file = f
        _items.value = read(f)
    }

    private fun read(f: File): List<Credential> {
        if (!f.exists()) return emptyList()
        return try {
            val json = String(CryptoBox.decrypt(f.readBytes()), Charsets.UTF_8)
            val arr = JSONArray(json)
            List(arr.length()) { Credential.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            // Keep the unreadable file instead of overwriting it.
            f.renameTo(File(f.parentFile, "vault.corrupt.${System.currentTimeMillis()}"))
            emptyList()
        }
    }

    @Synchronized
    private fun persist(list: List<Credential>) {
        val f = file ?: return
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeBytes(CryptoBox.encrypt(arr.toString().toByteArray(Charsets.UTF_8)))
        if (!tmp.renameTo(f)) {
            f.delete()
            tmp.renameTo(f)
        }
        _items.value = list
    }

    fun find(id: String): Credential? = _items.value.firstOrNull { it.id == id }

    fun upsert(c: Credential) {
        val list = _items.value.filterNot { it.id == c.id }.toMutableList()
        list.add(0, c.copy(updatedAt = System.currentTimeMillis()))
        persist(list)
    }

    fun delete(id: String) = persist(_items.value.filterNot { it.id == id })

    /**
     * Logins for an app package (exact match only) or a website (exact or sub-domain match).
     * Apps are matched strictly so a look-alike package can never receive another site's login.
     */
    fun matches(target: String, isWeb: Boolean): List<Credential> {
        val t = normalize(target)
        if (t.isEmpty()) return emptyList()
        return _items.value.filter { c ->
            val s = normalize(c.target)
            when {
                s.isEmpty() -> false
                s == t -> true
                isWeb -> t.endsWith(".$s") || s.endsWith(".$t")
                else -> false
            }
        }
    }

    fun saveFromAutofill(target: String, title: String, username: String, password: String): SaveResult {
        val t = normalize(target)
        val existing = _items.value.firstOrNull {
            normalize(it.target) == t && it.username.equals(username, ignoreCase = true)
        }
        return when {
            existing == null -> {
                upsert(Credential(title = title, username = username, password = password, target = target))
                SaveResult.CREATED
            }
            existing.password == password -> SaveResult.UNCHANGED
            else -> {
                upsert(existing.copy(password = password))
                SaveResult.UPDATED
            }
        }
    }

    fun normalize(raw: String): String {
        var s = raw.trim().lowercase()
        if (s.contains("://")) s = s.substringAfter("://")
        s = s.substringBefore('/').substringBefore('?').substringBefore('#').substringAfter('@')
        if (s.contains(':')) s = s.substringBefore(':')
        return s.removePrefix("www.").removePrefix("m.")
    }
}
