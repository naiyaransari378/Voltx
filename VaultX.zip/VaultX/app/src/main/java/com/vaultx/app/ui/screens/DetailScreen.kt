package com.vaultx.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vaultx.app.data.Vault
import com.vaultx.app.ui.components.Avatar
import com.vaultx.app.ui.components.NeuButton
import com.vaultx.app.ui.components.NeuCard
import com.vaultx.app.ui.components.NeuIconButton
import com.vaultx.app.ui.components.StrengthMeter
import com.vaultx.app.ui.components.TopBar
import com.vaultx.app.ui.theme.Neu
import com.vaultx.app.ui.theme.neu
import com.vaultx.app.util.ClipboardUtil
import com.vaultx.app.util.PasswordGenerator
import java.text.DateFormat
import java.util.Date
import kotlin.math.min

@Composable
fun DetailScreen(id: String, onBack: () -> Unit, onEdit: () -> Unit) {
    val p = Neu.colors
    val ctx = LocalContext.current
    val items by Vault.items.collectAsState()
    val c = items.firstOrNull { it.id == id }
    if (c == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    var reveal by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val strength = remember(c.password) { PasswordGenerator.strength(c.password) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
    ) {
        TopBar("Login", onBack) { NeuIconButton(Icons.Outlined.Edit, "Edit", onEdit, tint = p.accent) }
        Spacer(Modifier.height(28.dp))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Avatar(c.title, 88.dp)
            Spacer(Modifier.height(16.dp))
            Text(c.title, color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            if (c.target.isNotBlank()) Text(c.target, color = p.subText, fontSize = 14.sp)
        }
        Spacer(Modifier.height(28.dp))
        NeuCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(18.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                InfoRow(Icons.Outlined.Person, "Username", c.username.ifBlank { "—" }) {
                    if (c.username.isNotBlank()) {
                        NeuIconButton(Icons.Outlined.ContentCopy, "Copy username", {
                            ClipboardUtil.copy(ctx, "Username", c.username, sensitive = false)
                        }, size = 38.dp)
                    }
                }
                HorizontalDivider(color = p.dark.copy(alpha = 0.18f))
                InfoRow(
                    Icons.Outlined.Key, "Password",
                    if (reveal) c.password else "•".repeat(min(c.password.length, 14)),
                    mono = reveal,
                ) {
                    NeuIconButton(
                        if (reveal) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                        "Show password", { reveal = !reveal }, size = 38.dp,
                    )
                    Spacer(Modifier.width(10.dp))
                    NeuIconButton(Icons.Outlined.ContentCopy, "Copy password", {
                        ClipboardUtil.copy(ctx, "Password", c.password, sensitive = true)
                    }, size = 38.dp)
                }
                StrengthMeter(strength)
                if (c.target.isNotBlank()) {
                    HorizontalDivider(color = p.dark.copy(alpha = 0.18f))
                    InfoRow(Icons.Outlined.Language, "Website / App", c.target)
                }
                if (c.notes.isNotBlank()) {
                    HorizontalDivider(color = p.dark.copy(alpha = 0.18f))
                    InfoRow(Icons.Outlined.Description, "Notes", c.notes)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Updated " + DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(c.updatedAt)),
            color = p.subText, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))
        NeuButton(
            "Delete login", { confirmDelete = true }, Modifier.fillMaxWidth(),
            icon = Icons.Outlined.DeleteOutline, contentColor = p.danger,
        )
        Spacer(Modifier.height(24.dp))
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete login?") },
            text = { Text("“${c.title}” will be permanently removed from this device.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    Vault.delete(c.id)
                    onBack()
                }) { Text("Delete", color = p.danger) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
            containerColor = p.bg,
        )
    }
}

@Composable
private fun InfoRow(
    icon: ImageVector,
    label: String,
    value: String,
    mono: Boolean = false,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val p = Neu.colors
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).neu(p, elevation = 4.dp, inset = true, circle = true), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = p.accent, modifier = Modifier.size(19.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = p.subText, fontSize = 12.sp)
            Text(
                value, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium,
                fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default,
            )
        }
        actions()
    }
}
