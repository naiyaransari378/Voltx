package com.vaultx.app.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vaultx.app.security.Auth
import com.vaultx.app.ui.components.AccentButton
import com.vaultx.app.ui.components.NeuCard
import com.vaultx.app.ui.theme.Neu
import com.vaultx.app.ui.theme.neu

@Composable
fun LockScreen(onUnlock: () -> Unit) {
    val p = Neu.colors
    val ctx = LocalContext.current
    val canAuth = remember { Auth.canAuthenticate(ctx) }
    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(
        initialValue = 1f, targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "scale",
    )

    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier
                .size(176.dp)
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .neu(p, elevation = 12.dp, circle = true),
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(122.dp).neu(p, elevation = 8.dp, inset = true, circle = true), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(78.dp)
                        .neu(p, elevation = 6.dp, circle = true, fill = p.accent)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(p.accent, p.accent2))),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Outlined.Lock, null, tint = Color.White, modifier = Modifier.size(36.dp))
                }
            }
        }
        Spacer(Modifier.height(48.dp))
        Text("VaultX", fontSize = 36.sp, fontWeight = FontWeight.ExtraBold, color = p.text)
        Spacer(Modifier.height(8.dp))
        Text(
            "Your passwords. Encrypted.\nStored only on this device.",
            color = p.subText, fontSize = 15.sp, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(44.dp))
        AccentButton("Unlock vault", onUnlock, Modifier.fillMaxWidth(), icon = Icons.Outlined.Fingerprint)
        if (!canAuth) {
            Spacer(Modifier.height(24.dp))
            NeuCard(Modifier.fillMaxWidth(), inset = true) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.WarningAmber, null, tint = p.danger)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "No screen lock is set. Add a PIN, pattern or fingerprint in system settings to protect your vault.",
                        color = p.subText, fontSize = 13.sp,
                    )
                }
            }
        }
    }
}
