package com.vaultx.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vaultx.app.Session
import com.vaultx.app.data.Credential
import com.vaultx.app.data.SecurityHealth
import com.vaultx.app.data.Vault
import com.vaultx.app.ui.components.AccentButton
import com.vaultx.app.ui.components.Avatar
import com.vaultx.app.ui.components.NeuCard
import com.vaultx.app.ui.components.NeuIconButton
import com.vaultx.app.ui.components.NeuTextField
import com.vaultx.app.ui.theme.Neu
import com.vaultx.app.ui.theme.neu
import com.vaultx.app.util.AutofillHelper
import com.vaultx.app.util.ClipboardUtil

@Composable
fun HomeScreen(onOpen: (String) -> Unit, onAdd: () -> Unit, onSettings: () -> Unit) {
    val p = Neu.colors
    val ctx = LocalContext.current
    val all by Vault.items.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    val tick = Session.resumeTick
    val autofillOn = remember(tick) { AutofillHelper.isEnabled(ctx) }
    val filtered = remember(all, query) {
        val q = query.trim()
        val list = if (q.isEmpty()) all else all.filter {
            it.title.contains(q, true) || it.username.contains(q, true) || it.target.contains(q, true)
        }
        list.sortedBy { it.title.lowercase() }
    }
    val health = remember(all) { SecurityHealth.of(all) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, top = 16.dp, end = 20.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("VaultX", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = p.text)
                        Text(
                            if (all.size == 1) "1 password secured" else "${all.size} passwords secured",
                            color = p.subText, fontSize = 14.sp,
                        )
                    }
                    NeuIconButton(Icons.Outlined.Settings, "Settings", onSettings)
                }
            }
            item {
                NeuTextField(query, { query = it }, placeholder = "Search logins", leading = Icons.Outlined.Search)
            }
            if (!autofillOn) {
                item {
                    NeuCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(18.dp)) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.AutoAwesome, null, tint = p.accent)
                                Spacer(Modifier.width(10.dp))
                                Text("Turn on Autofill", color = p.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Let VaultX fill and save passwords automatically in apps and browsers.",
                                color = p.subText, fontSize = 13.sp,
                            )
                            Spacer(Modifier.height(14.dp))
                            AccentButton("Enable autofill", { AutofillHelper.openSettings(ctx) }, Modifier.fillMaxWidth())
                        }
                    }
                }
            }
            if (all.isNotEmpty() && query.isBlank()) {
                item { HealthCard(health) }
            }
            if (filtered.isEmpty()) {
                item { EmptyState(searching = query.isNotBlank()) }
            }
            items(filtered, key = { it.id }) { c ->
                CredentialRow(c, onClick = { onOpen(c.id) }, onCopy = {
                    ClipboardUtil.copy(ctx, "Password", c.password, sensitive = true)
                })
            }
        }
        AddFab(onAdd, Modifier.align(Alignment.BottomEnd).padding(24.dp))
    }
}

@Composable
private fun CredentialRow(c: Credential, onClick: () -> Unit, onCopy: () -> Unit) {
    val p = Neu.colors
    NeuCard(Modifier.fillMaxWidth(), onClick = onClick, contentPadding = PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(c.title, 50.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    c.title, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    c.username.ifBlank { c.target }, color = p.subText, fontSize = 13.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.width(8.dp))
            NeuIconButton(Icons.Outlined.ContentCopy, "Copy password", onCopy, size = 40.dp)
        }
    }
}

@Composable
private fun HealthCard(h: SecurityHealth) {
    val p = Neu.colors
    val color = when {
        h.score >= 80 -> p.success
        h.score >= 50 -> Color(0xFFF5A623)
        else -> p.danger
    }
    NeuCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(80.dp).neu(p, elevation = 5.dp, inset = true, circle = true), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { h.score / 100f },
                    modifier = Modifier.size(64.dp),
                    color = color,
                    strokeWidth = 6.dp,
                    trackColor = Color.Transparent,
                    strokeCap = StrokeCap.Round,
                )
                Text("${h.score}", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = p.text)
            }
            Spacer(Modifier.width(18.dp))
            Column(Modifier.weight(1f)) {
                Text("Security health", color = p.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(4.dp))
                Text("${h.weak} weak  ·  ${h.reused} reused", color = p.subText, fontSize = 13.sp)
                Text(
                    if (h.score >= 80) "Looking great!" else "Update weak or reused passwords",
                    color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                )
            }
        }
    }
}

@Composable
private fun EmptyState(searching: Boolean) {
    val p = Neu.colors
    Column(Modifier.fillMaxWidth().padding(top = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(110.dp).neu(p, elevation = 9.dp, circle = true), contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.Shield, null, tint = p.accent, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text(
            if (searching) "No matches" else "Your vault is empty",
            color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            if (searching) "Try another name, email or website."
            else "Tap + to add a login, or just sign in to any app —\nVaultX will offer to save it automatically.",
            color = p.subText, fontSize = 13.sp, textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun AddFab(onClick: () -> Unit, modifier: Modifier) {
    val p = Neu.colors
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    Box(
        modifier
            .size(66.dp)
            .neu(p, elevation = if (pressed) 3.dp else 9.dp, circle = true, fill = p.accent)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(p.accent, p.accent2)))
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Outlined.Add, "Add login", tint = Color.White, modifier = Modifier.size(30.dp))
    }
}
