package com.vaultx.app.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vaultx.app.ui.theme.Neu
import com.vaultx.app.ui.theme.neu
import com.vaultx.app.util.PasswordGenerator

@Composable
fun NeuCard(
    modifier: Modifier = Modifier,
    radius: Dp = 22.dp,
    elevation: Dp = 7.dp,
    inset: Boolean = false,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val p = Neu.colors
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val elev by animateDpAsState(if (pressed) 2.dp else elevation, label = "elev")
    val clickMod = if (onClick != null) {
        Modifier.clickable(interactionSource = interaction, indication = null, onClick = onClick)
    } else Modifier
    Box(
        modifier = modifier
            .neu(p, radius = radius, elevation = elev, inset = inset || pressed)
            .clip(RoundedCornerShape(radius))
            .then(clickMod)
            .padding(contentPadding),
        content = content,
    )
}

@Composable
fun NeuIconButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 46.dp,
    tint: Color = Neu.colors.subText,
) {
    val p = Neu.colors
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    Box(
        modifier
            .size(size)
            .neu(p, elevation = if (pressed) 2.dp else 5.dp, inset = pressed, circle = true)
            .clip(CircleShape)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription, tint = if (pressed) p.accent else tint, modifier = Modifier.size(size * 0.44f))
    }
}

@Composable
fun AccentButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
) {
    val p = Neu.colors
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    Box(
        modifier
            .height(56.dp)
            .neu(p, radius = 18.dp, elevation = if (pressed) 2.dp else 7.dp, fill = p.accent)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.linearGradient(listOf(p.accent, p.accent2)))
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
            }
            Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        }
    }
}

@Composable
fun NeuButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    contentColor: Color = Neu.colors.accent,
) {
    val p = Neu.colors
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    Box(
        modifier
            .height(52.dp)
            .neu(p, radius = 16.dp, elevation = if (pressed) 2.dp else 6.dp, inset = pressed)
            .clip(RoundedCornerShape(16.dp))
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(icon, null, tint = contentColor, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
            }
            Text(text, color = contentColor, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        }
    }
}

@Composable
fun NeuTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    placeholder: String = "",
    leading: ImageVector? = null,
    isPassword: Boolean = false,
    singleLine: Boolean = true,
    minLines: Int = 1,
    keyboardType: KeyboardType = KeyboardType.Text,
    trailing: (@Composable RowScope.() -> Unit)? = null,
) {
    val p = Neu.colors
    var visible by remember { mutableStateOf(false) }
    Column(modifier) {
        if (label != null) {
            Text(
                label, color = p.subText, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(start = 6.dp, bottom = 8.dp),
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 54.dp)
                .neu(p, radius = 16.dp, elevation = 5.dp, inset = true)
                .padding(horizontal = 14.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (leading != null) {
                Icon(leading, null, tint = p.accent, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(12.dp))
            }
            Box(Modifier.weight(1f).padding(vertical = 12.dp)) {
                if (value.isEmpty()) Text(placeholder, color = p.subText.copy(alpha = 0.6f), fontSize = 16.sp)
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    singleLine = singleLine,
                    minLines = minLines,
                    textStyle = TextStyle(
                        color = p.text, fontSize = 16.sp,
                        fontFamily = if (isPassword && visible) FontFamily.Monospace else FontFamily.Default,
                    ),
                    cursorBrush = SolidColor(p.accent),
                    visualTransformation = if (isPassword && !visible) PasswordVisualTransformation() else VisualTransformation.None,
                    keyboardOptions = KeyboardOptions(keyboardType = if (isPassword) KeyboardType.Password else keyboardType),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (isPassword) {
                Icon(
                    if (visible) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                    contentDescription = "Show password",
                    tint = p.subText,
                    modifier = Modifier
                        .padding(start = 8.dp)
                        .size(22.dp)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { visible = !visible },
                )
            }
            trailing?.invoke(this)
        }
    }
}

@Composable
fun NeuSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val p = Neu.colors
    val offset by animateDpAsState(if (checked) 24.dp else 0.dp, label = "knob")
    Box(
        Modifier
            .size(width = 56.dp, height = 32.dp)
            .neu(p, radius = 16.dp, elevation = 3.dp, inset = true)
            .clip(RoundedCornerShape(16.dp))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onCheckedChange(!checked) }
            .padding(4.dp),
    ) {
        Box(
            Modifier
                .offset(x = offset)
                .size(24.dp)
                .neu(p, elevation = 2.dp, circle = true, fill = if (checked) p.accent else p.bg),
        )
    }
}

private val avatarGradients = listOf(
    Color(0xFF5B6CFF) to Color(0xFF8A5BFF),
    Color(0xFF00B4DB) to Color(0xFF0083B0),
    Color(0xFFFF6A88) to Color(0xFFFF99AC),
    Color(0xFF11998E) to Color(0xFF38EF7D),
    Color(0xFFF7971E) to Color(0xFFFFC837),
    Color(0xFFDA22FF) to Color(0xFF9733EE),
)

@Composable
fun Avatar(name: String, size: Dp = 48.dp) {
    val p = Neu.colors
    val g = avatarGradients[(name.lowercase().hashCode() and 0x7fffffff) % avatarGradients.size]
    Box(Modifier.size(size).neu(p, elevation = 5.dp, circle = true), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .size(size - 10.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(g.first, g.second))),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                name.trim().firstOrNull()?.uppercase() ?: "?",
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.36f).sp,
            )
        }
    }
}

@Composable
fun StrengthMeter(score: Int, modifier: Modifier = Modifier) {
    val p = Neu.colors
    val palette = listOf(p.danger, Color(0xFFFF8A3D), Color(0xFFF5C33B), Color(0xFF3BC47A), Color(0xFF22B8CF))
    val active = palette[score.coerceIn(0, 4)]
    Column(modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(4) { i ->
                Box(
                    Modifier
                        .weight(1f)
                        .height(8.dp)
                        .neu(p, radius = 4.dp, elevation = 2.dp, inset = true)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (i < score) active else Color.Transparent),
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(PasswordGenerator.label(score), color = active, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun TopBar(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        NeuIconButton(Icons.AutoMirrored.Outlined.ArrowBack, "Back", onBack)
        Text(
            title,
            modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
            color = Neu.colors.text, fontSize = 20.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
        actions()
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text.uppercase(), color = Neu.colors.subText, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp, modifier = Modifier.padding(start = 6.dp, top = 8.dp, bottom = 12.dp),
    )
}

@Composable
fun ToggleRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = Neu.colors.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        NeuSwitch(checked, onChange)
    }
}

@Composable
fun SettingSwitch(icon: ImageVector, title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = Neu.colors
    NeuCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).neu(p, elevation = 4.dp, inset = true, circle = true), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = p.accent, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(subtitle, color = p.subText, fontSize = 12.sp)
            }
            Spacer(Modifier.width(10.dp))
            NeuSwitch(checked, onChange)
        }
    }
}
