package com.vaultx.app.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.autofill.AutofillManager

object AutofillHelper {
    fun isEnabled(ctx: Context): Boolean = try {
        ctx.getSystemService(AutofillManager::class.java)?.hasEnabledAutofillServices() == true
    } catch (e: Exception) {
        false
    }

    fun openSettings(ctx: Context) {
        val intent = if (isEnabled(ctx)) {
            Intent(Settings.ACTION_SETTINGS)
        } else {
            Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE).setData(Uri.parse("package:${ctx.packageName}"))
        }
        try {
            ctx.startActivity(intent)
        } catch (e: Exception) {
            try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { }
        }
    }
}
