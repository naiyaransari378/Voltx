package com.vaultx.app.util

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.widget.Toast

object ClipboardUtil {
    private const val CLEAR_AFTER_MS = 30_000L

    fun copy(context: Context, label: String, text: String, sensitive: Boolean) {
        val cm = context.getSystemService(ClipboardManager::class.java) ?: return
        val clip = ClipData.newPlainText(label, text)
        if (sensitive && Build.VERSION.SDK_INT >= 33) {
            clip.description.extras = PersistableBundle().apply {
                putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
            }
        }
        cm.setPrimaryClip(clip)
        if (Build.VERSION.SDK_INT < 33) {
            Toast.makeText(context, "$label copied", Toast.LENGTH_SHORT).show()
        }
        if (sensitive) {
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    val current = cm.primaryClip?.getItemAt(0)?.text?.toString()
                    if (current == text) {
                        if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip()
                        else cm.setPrimaryClip(ClipData.newPlainText("", ""))
                    }
                } catch (_: Exception) { }
            }, CLEAR_AFTER_MS)
        }
    }
}
