package com.vaultx.app.data

import com.vaultx.app.util.PasswordGenerator

data class SecurityHealth(val total: Int, val weak: Int, val reused: Int) {
    val score: Int
        get() = if (total == 0) 100 else (100 - (weak + reused) * 100 / (total * 2)).coerceIn(0, 100)

    companion object {
        fun of(items: List<Credential>): SecurityHealth {
            val counts = items.groupingBy { it.password }.eachCount()
            return SecurityHealth(
                total = items.size,
                weak = items.count { PasswordGenerator.strength(it.password) <= 1 },
                reused = items.count { (counts[it.password] ?: 0) > 1 },
            )
        }
    }
}
