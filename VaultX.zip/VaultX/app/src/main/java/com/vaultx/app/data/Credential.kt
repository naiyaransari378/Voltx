package com.vaultx.app.data

import org.json.JSONObject
import java.util.UUID

data class Credential(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val username: String,
    val password: String,
    val target: String,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("title", title)
        .put("username", username)
        .put("password", password)
        .put("target", target)
        .put("notes", notes)
        .put("createdAt", createdAt)
        .put("updatedAt", updatedAt)

    // Never leak secrets into logs.
    override fun toString(): String = "Credential(id=$id, title=$title)"

    companion object {
        fun fromJson(o: JSONObject) = Credential(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            title = o.optString("title"),
            username = o.optString("username"),
            password = o.optString("password"),
            target = o.optString("target"),
            notes = o.optString("notes"),
            createdAt = o.optLong("createdAt", System.currentTimeMillis()),
            updatedAt = o.optLong("updatedAt", System.currentTimeMillis()),
        )
    }
}
