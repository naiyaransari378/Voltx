package com.vaultx.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Title
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vaultx.app.data.Credential
import com.vaultx.app.data.Vault
import com.vaultx.app.ui.components.AccentButton
import com.vaultx.app.ui.components.NeuButton
import com.vaultx.app.ui.components.NeuCard
import com.vaultx.app.ui.components.NeuIconButton
import com.vaultx.app.ui.components.NeuTextField
import com.vaultx.app.ui.components.StrengthMeter
import com.vaultx.app.ui.components.ToggleRow
import com.vaultx.app.ui.components.TopBar
import com.vaultx.app.ui.theme.Neu
import com.vaultx.app.util.PasswordGenerator

@Composable
fun EditScreen(id: String?, onBack: () -> Unit) {
    val p = Neu.colors
    val existing = remember(id) { id?.let { Vault.find(it) } }

    var title by rememberSaveable { mutableStateOf(existing?.title.orEmpty()) }
    var username by rememberSaveable { mutableStateOf(existing?.username.orEmpty()) }
    var password by rememberSaveable { mutableStateOf(existing?.password.orEmpty()) }
    var target by rememberSaveable { mutableStateOf(existing?.target.orEmpty()) }
    var notes by rememberSaveable { mutableStateOf(existing?.notes.orEmpty()) }

    var showGenerator by rememberSaveable { mutableStateOf(false) }
    var length by rememberSaveable { mutableFloatStateOf(18f) }
    var upper by rememberSaveable { mutableStateOf(true) }
    var digits by rememberSaveable { mutableStateOf(true) }
    var symbols by rememberSaveable { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    val regenerate: () -> Unit = {
        password = PasswordGenerator.generate(length.toInt(), upper, digits, symbols)
    }

    val save: () -> Unit = save@{
        val finalTitle = title.trim().ifBlank { Vault.normalize(target) }
        when {
            password.isBlank() -> error = "Password is required"
            finalTitle.isBlank() -> error = "Add a title or website"
            else -> {
                val base = existing ?: Credential(title = finalTitle, username = "", password = "", target = "")
                Vault.upsert(
                    base.copy(
                        title = finalTitle,
                        username = username.trim(),
                        password = password,
                        target = target.trim(),
                        notes = notes.trim(),
                    )
                )
                onBack()
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        TopBar(if (existing == null) "New login" else "Edit login", onBack) {
            NeuIconButton(Icons.Outlined.Check, "Save", save, tint = p.accent)
        }
        NeuTextField(title, { title = it; error = null }, label = "Title", placeholder = "e.g. Instagram", leading = Icons.Outlined.Title)
        NeuTextField(
            username, { username = it }, label = "Username or email", placeholder = "name@example.com",
            leading = Icons.Outlined.Person, keyboardType = KeyboardType.Email,
        )
        Column {
            NeuTextField(
                password, { password = it; error = null }, label = "Password", placeholder = "Enter or generate",
                leading = Icons.Outlined.Key, isPassword = true,
            )
            if (password.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                StrengthMeter(PasswordGenerator.strength(password), Modifier.padding(horizontal = 6.dp))
            }
        }

        NeuButton(
            if (showGenerator) "Hide generator" else "Generate strong password",
            {
                showGenerator = !showGenerator
                if (showGenerator) regenerate()
            },
            Modifier.fillMaxWidth(),
            icon = Icons.Outlined.AutoAwesome,
        )

        AnimatedVisibility(showGenerator) {
            NeuCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(18.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Length", color = p.text, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("${length.toInt()}", color = p.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Slider(
                        value = length,
                        onValueChange = { length = it; regenerate() },
                        valueRange = 8f..48f,
                        steps = 39,
                        colors = SliderDefaults.colors(
                            thumbColor = p.accent,
                            activeTrackColor = p.accent,
                            inactiveTrackColor = p.dark.copy(alpha = 0.35f),
                            activeTickColor = Color.Transparent,
                            inactiveTickColor = Color.Transparent,
                        ),
                    )
                    ToggleRow("Uppercase  A–Z", upper) { upper = it; regenerate() }
                    ToggleRow("Numbers  0–9", digits) { digits = it; regenerate() }
                    ToggleRow("Symbols  !@#", symbols) { symbols = it; regenerate() }
                    Row {
                        NeuButton("Regenerate", regenerate, Modifier.weight(1f), icon = Icons.Outlined.Refresh)
                        Spacer(Modifier.width(12.dp))
                        NeuButton("Done", { showGenerator = false }, Modifier.weight(1f), icon = Icons.Outlined.Check, contentColor = p.subText)
                    }
                }
            }
        }

        NeuTextField(
            target, { target = it; error = null }, label = "Website or app",
            placeholder = "instagram.com or com.instagram.android",
            leading = Icons.Outlined.Language, keyboardType = KeyboardType.Uri,
        )
        NeuTextField(
            notes, { notes = it }, label = "Notes", placeholder = "Optional",
            leading = Icons.Outlined.Description, singleLine = false, minLines = 3,
        )

        error?.let { Text(it, color = p.danger, fontSize = 14.sp, modifier = Modifier.padding(start = 6.dp)) }

        AccentButton("Save login", save, Modifier.fillMaxWidth(), icon = Icons.Outlined.Check)
        Spacer(Modifier.height(12.dp))
    }
}
