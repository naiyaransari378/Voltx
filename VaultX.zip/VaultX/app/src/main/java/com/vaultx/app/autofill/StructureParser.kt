package com.vaultx.app.autofill

import android.app.assist.AssistStructure
import android.app.assist.AssistStructure.ViewNode
import android.text.InputType
import android.view.View
import android.view.autofill.AutofillId

class ParsedFields(val packageName: String) {
    var webDomain: String? = null
    var usernameId: AutofillId? = null
    var passwordId: AutofillId? = null
    var usernameValue: String? = null
    var passwordValue: String? = null

    val isWeb: Boolean get() = !webDomain.isNullOrBlank()
    val target: String get() = webDomain?.takeIf { it.isNotBlank() } ?: packageName
    val ids: Array<AutofillId> get() = listOfNotNull(usernameId, passwordId).toTypedArray()
}

/** Finds username / password fields in native apps, WebViews and browsers. */
object StructureParser {
    private val USER_WORDS = listOf("user", "email", "e-mail", "login", "account", "phone", "mobile", "identifier")
    private val PASS_WORDS = listOf("password", "passwd", "pass", "pwd", "secret")

    fun parse(structure: AssistStructure): ParsedFields {
        val result = ParsedFields(structure.activityComponent?.packageName.orEmpty())
        var lastText: ViewNode? = null

        fun visit(node: ViewNode) {
            val domain = node.webDomain
            if (!domain.isNullOrBlank() && result.webDomain == null) result.webDomain = domain

            val id = node.autofillId
            if (id != null && node.autofillType == View.AUTOFILL_TYPE_TEXT && node.visibility == View.VISIBLE) {
                if (isPassword(node)) {
                    if (result.passwordId == null) {
                        result.passwordId = id
                        result.passwordValue = textOf(node)
                        if (result.usernameId == null) {
                            lastText?.let { prev ->
                                result.usernameId = prev.autofillId
                                result.usernameValue = textOf(prev)
                            }
                        }
                    }
                } else {
                    if (result.usernameId == null && isUsername(node)) {
                        result.usernameId = id
                        result.usernameValue = textOf(node)
                    }
                    lastText = node
                }
            }
            for (i in 0 until node.childCount) visit(node.getChildAt(i))
        }

        for (i in 0 until structure.windowNodeCount) visit(structure.getWindowNodeAt(i).rootViewNode)
        return result
    }

    private fun textOf(node: ViewNode): String? {
        val v = node.autofillValue ?: return null
        return if (v.isText) v.textValue?.toString() else null
    }

    private fun keywords(node: ViewNode): String = listOfNotNull(
        node.idEntry,
        node.hint,
        node.contentDescription?.toString(),
        node.htmlInfo?.attributes?.joinToString(" ") { "${it.first}=${it.second}" },
    ).joinToString(" ").lowercase()

    private fun isPassword(node: ViewNode): Boolean {
        node.autofillHints?.let { hints ->
            if (hints.any { it.contains("password", ignoreCase = true) }) return true
        }
        val type = node.inputType
        val cls = type and InputType.TYPE_MASK_CLASS
        val variation = type and InputType.TYPE_MASK_VARIATION
        if (cls == InputType.TYPE_CLASS_TEXT && (
                variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
        ) return true
        if (cls == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD) return true
        val k = keywords(node)
        if (k.contains("type=password")) return true
        return PASS_WORDS.any { k.contains(it) }
    }

    private fun isUsername(node: ViewNode): Boolean {
        node.autofillHints?.let { hints ->
            if (hints.any { h ->
                    h.contains("username", true) || h.contains("email", true) || h.contains("phone", true)
                }
            ) return true
        }
        val type = node.inputType
        val cls = type and InputType.TYPE_MASK_CLASS
        val variation = type and InputType.TYPE_MASK_VARIATION
        if (cls == InputType.TYPE_CLASS_TEXT && (
                variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS)
        ) return true
        val k = keywords(node)
        if (k.contains("type=email") || k.contains("type=tel")) return true
        return USER_WORDS.any { k.contains(it) }
    }
}
