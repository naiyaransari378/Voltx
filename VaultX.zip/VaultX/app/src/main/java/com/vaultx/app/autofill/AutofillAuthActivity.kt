package com.vaultx.app.autofill

import android.content.Intent
import android.os.Bundle
import android.service.autofill.Dataset
import android.view.autofill.AutofillId
import android.view.autofill.AutofillManager
import android.view.autofill.AutofillValue
import android.widget.RemoteViews
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.IntentCompat
import com.vaultx.app.R
import com.vaultx.app.data.Vault
import com.vaultx.app.security.Auth

/** Shown when the user taps a VaultX suggestion: verifies identity, then returns the filled dataset. */
class AutofillAuthActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return
        Auth.authenticate(
            this,
            getString(R.string.unlock_title),
            getString(R.string.autofill_unlock_subtitle),
            onSuccess = { deliver() },
            onFail = { cancel() },
        )
    }

    @Suppress("DEPRECATION")
    private fun deliver() {
        Vault.init(this)
        val cred = intent.getStringExtra(EXTRA_CRED_ID)?.let { Vault.find(it) }
        val userId = IntentCompat.getParcelableExtra(intent, EXTRA_USER_ID, AutofillId::class.java)
        val passId = IntentCompat.getParcelableExtra(intent, EXTRA_PASS_ID, AutofillId::class.java)
        if (cred == null) { cancel(); return }

        val pres = RemoteViews(packageName, R.layout.autofill_item).apply {
            setTextViewText(R.id.title, cred.title)
            setTextViewText(R.id.subtitle, cred.username)
        }
        val builder = Dataset.Builder(pres)
        var count = 0
        if (userId != null && cred.username.isNotBlank()) {
            builder.setValue(userId, AutofillValue.forText(cred.username)); count++
        }
        if (passId != null) {
            builder.setValue(passId, AutofillValue.forText(cred.password)); count++
        }
        if (count == 0) { cancel(); return }

        setResult(RESULT_OK, Intent().putExtra(AutofillManager.EXTRA_AUTHENTICATION_RESULT, builder.build()))
        finish()
    }

    private fun cancel() {
        setResult(RESULT_CANCELED)
        finish()
    }

    companion object {
        const val EXTRA_CRED_ID = "vaultx.cred_id"
        const val EXTRA_USER_ID = "vaultx.user_id"
        const val EXTRA_PASS_ID = "vaultx.pass_id"
    }
}
