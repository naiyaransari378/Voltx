package com.vaultx.app.data

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("vaultx_prefs", Context.MODE_PRIVATE)

    fun autoSave(c: Context) = sp(c).getBoolean("auto_save", true)
    fun setAutoSave(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto_save", v).apply()

    fun autoLock(c: Context) = sp(c).getBoolean("auto_lock", true)
    fun setAutoLock(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto_lock", v).apply()
}
