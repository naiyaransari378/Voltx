package com.vaultx.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.vaultx.app.data.Prefs
import com.vaultx.app.data.Vault
import com.vaultx.app.security.Auth
import com.vaultx.app.ui.VaultApp
import com.vaultx.app.ui.theme.VaultTheme

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Block screenshots / screen recording and hide content in the recents screen.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        enableEdgeToEdge()
        Vault.init(this)
        setContent {
            VaultTheme {
                VaultApp(onUnlock = { unlock() }, onLock = { Session.lock() })
            }
        }
        if (savedInstanceState == null && !Session.unlocked) unlock()
    }

    private fun unlock() {
        Auth.authenticate(
            this,
            getString(R.string.unlock_title),
            getString(R.string.unlock_subtitle),
            onSuccess = { Session.unlocked = true },
            onFail = { },
        )
    }

    override fun onResume() {
        super.onResume()
        Session.resumeTick++
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations && Prefs.autoLock(this)) Session.lock()
    }
}
