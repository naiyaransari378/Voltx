package com.vaultx.app.ui.theme

import android.graphics.BlurMaskFilter
import android.graphics.RectF
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.min

@Immutable
data class NeuPalette(
    val bg: Color,
    val light: Color,
    val dark: Color,
    val text: Color,
    val subText: Color,
    val accent: Color,
    val accent2: Color,
    val danger: Color,
    val success: Color,
)

val LightNeu = NeuPalette(
    bg = Color(0xFFE4E9F2),
    light = Color(0xFFFFFFFF),
    dark = Color(0xFFA9B6CC),
    text = Color(0xFF2B3445),
    subText = Color(0xFF6E7A90),
    accent = Color(0xFF5B6CFF),
    accent2 = Color(0xFF8A5BFF),
    danger = Color(0xFFE5484D),
    success = Color(0xFF2FB37A),
)

val DarkNeu = NeuPalette(
    bg = Color(0xFF262A33),
    light = Color(0xFF333845),
    dark = Color(0xFF15171C),
    text = Color(0xFFE7EAF0),
    subText = Color(0xFF9AA3B4),
    accent = Color(0xFF7C8BFF),
    accent2 = Color(0xFFA78BFA),
    danger = Color(0xFFFF6B6B),
    success = Color(0xFF4ADE9B),
)

val LocalNeu = staticCompositionLocalOf { LightNeu }

object Neu {
    val colors: NeuPalette
        @Composable @ReadOnlyComposable get() = LocalNeu.current
}

@Composable
fun VaultTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val p = if (dark) DarkNeu else LightNeu
    val scheme = if (dark) {
        darkColorScheme(
            primary = p.accent, secondary = p.accent2, background = p.bg, surface = p.bg,
            onBackground = p.text, onSurface = p.text, error = p.danger, surfaceContainerHigh = p.bg,
        )
    } else {
        lightColorScheme(
            primary = p.accent, secondary = p.accent2, background = p.bg, surface = p.bg,
            onBackground = p.text, onSurface = p.text, error = p.danger, surfaceContainerHigh = p.bg,
        )
    }
    CompositionLocalProvider(LocalNeu provides p) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

/**
 * Neumorphic surface: soft light shadow top-left + dark shadow bottom-right (raised),
 * or inner shadows (inset / pressed).
 */
fun Modifier.neu(
    p: NeuPalette,
    radius: Dp = 20.dp,
    elevation: Dp = 6.dp,
    inset: Boolean = false,
    circle: Boolean = false,
    fill: Color? = null,
): Modifier = this.drawBehind {
    val w = size.width
    val h = size.height
    if (w <= 0f || h <= 0f) return@drawBehind
    val r = if (circle) min(w, h) / 2f else min(radius.toPx(), min(w, h) / 2f)
    val e = elevation.toPx()
    val canvas = drawContext.canvas.nativeCanvas
    val rect = RectF(0f, 0f, w, h)
    val base = (fill ?: p.bg).toArgb()

    if (!inset) {
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = base }
        if (e > 0f) {
            paint.setShadowLayer(e * 1.8f, -e * 0.9f, -e * 0.9f, p.light.toArgb())
            canvas.drawRoundRect(rect, r, r, paint)
            paint.setShadowLayer(e * 1.8f, e * 0.9f, e * 0.9f, p.dark.toArgb())
        }
        canvas.drawRoundRect(rect, r, r, paint)
    } else {
        val saved = canvas.save()
        val path = android.graphics.Path().apply {
            addRoundRect(rect, r, r, android.graphics.Path.Direction.CW)
        }
        canvas.clipPath(path)
        canvas.drawColor(base)
        if (e > 0f) {
            val stroke = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                style = android.graphics.Paint.Style.STROKE
                strokeWidth = e * 2f
                maskFilter = BlurMaskFilter(e, BlurMaskFilter.Blur.NORMAL)
            }
            val shift = e * 0.7f
            stroke.color = p.dark.toArgb()
            canvas.save(); canvas.translate(shift, shift); canvas.drawRoundRect(rect, r, r, stroke); canvas.restore()
            stroke.color = p.light.toArgb()
            canvas.save(); canvas.translate(-shift, -shift); canvas.drawRoundRect(rect, r, r, stroke); canvas.restore()
        }
        canvas.restoreToCount(saved)
    }
}
