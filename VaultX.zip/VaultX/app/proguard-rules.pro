# VaultX – classes referenced from the manifest (activities, autofill service) are kept automatically.
-keepattributes *Annotation*
