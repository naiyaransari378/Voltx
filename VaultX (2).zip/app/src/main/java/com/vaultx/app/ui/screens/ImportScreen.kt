package com.vaultx.app.ui.screens

import android.content.Context
import android.content.ContextWrapper
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Upload
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.vaultx.app.Session
import com.vaultx.app.data.CsvTransfer
import com.vaultx.app.data.ImportResult
import com.vaultx.app.data.Vault
import com.vaultx.app.security.Auth
import com.vaultx.app.ui.components.AccentButton
import com.vaultx.app.ui.components.NeuButton
import com.vaultx.app.ui.components.NeuCard
import com.vaultx.app.ui.components.SectionLabel
import com.vaultx.app.ui.components.TopBar
import com.vaultx.app.ui.theme.Neu
import com.vaultx.app.ui.theme.neu
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val MAX_FILE_BYTES = 20 * 1024 * 1024

private val CSV_MIME_TYPES = arrayOf(
    "text/*", "text/csv", "text/comma-separated-values", "application/csv",
    "application/vnd.ms-excel", "application/octet-stream",
)

private fun Context.findActivity(): FragmentActivity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is FragmentActivity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun ImportScreen(onBack: () -> Unit) {
    val p = Neu.colors
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val count = Vault.items.collectAsState().value.size

    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ImportResult?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmExport by remember { mutableStateOf(false) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        Session.suppressAutoLock = false
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true; error = null; result = null
        scope.launch {
            try {
                val parsed = withContext(Dispatchers.IO) {
                    val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: throw CsvTransfer.ParseException("Could not open this file.")
                    if (bytes.size > MAX_FILE_BYTES) throw CsvTransfer.ParseException("This file is too large.")
                    CsvTransfer.parse(String(bytes, Charsets.UTF_8))
                }
                if (parsed.isEmpty()) {
                    error = "No logins with passwords were found in this file."
                } else {
                    result = withContext(Dispatchers.IO) { Vault.importAll(parsed) }
                }
            } catch (e: CsvTransfer.ParseException) {
                error = e.message
            } catch (e: Exception) {
                error = "Import failed. Make sure you picked the exported .csv file."
            }
            busy = false
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        Session.suppressAutoLock = false
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val items = Vault.items.value
                withContext(Dispatchers.IO) {
                    val out = ctx.contentResolver.openOutputStream(uri) ?: throw IllegalStateException()
                    out.use { it.write(CsvTransfer.toCsv(items).toByteArray(Charsets.UTF_8)) }
                }
                Toast.makeText(ctx, "Exported ${items.size} logins", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                error = "Export failed. Please try another folder."
            }
        }
    }

    val pickFile: () -> Unit = {
        Session.suppressAutoLock = true
        importLauncher.launch(CSV_MIME_TYPES)
    }

    val startExport: () -> Unit = {
        val activity = ctx.findActivity()
        if (activity != null) {
            Session.suppressAutoLock = true
            Auth.authenticate(
                activity, "Confirm export", "Verify it's you to export all passwords",
                onSuccess = {
                    val stamp = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                    exportLauncher.launch("VaultX-backup-$stamp.csv")
                },
                onFail = { Session.suppressAutoLock = false },
            )
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
    ) {
        TopBar("Import & export", onBack)
        Spacer(Modifier.height(28.dp))

        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(112.dp).neu(p, elevation = 10.dp, circle = true), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(70.dp)
                        .neu(p, elevation = 5.dp, circle = true, fill = p.accent)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(p.accent, p.accent2))),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Outlined.Download, null, tint = Color.White, modifier = Modifier.size(32.dp))
                }
            }
            Spacer(Modifier.height(20.dp))
            Text("Bring all your passwords", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "Move every login from Google, Chrome, Samsung Pass, Bitwarden and other apps into VaultX in one go.",
                color = p.subText, fontSize = 14.sp, textAlign = TextAlign.Center,
            )
        }

        Spacer(Modifier.height(24.dp))
        NeuCard(Modifier.fillMaxWidth(), inset = true, contentPadding = PaddingValues(16.dp)) {
            Row {
                Icon(Icons.Outlined.Info, null, tint = p.accent, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(12.dp))
                Text(
                    "Android keeps each app's saved passwords private, so no app can read them directly. " +
                        "Export them once as a CSV file from your old password manager, then pick that file here.",
                    color = p.subText, fontSize = 13.sp,
                )
            }
        }

        Spacer(Modifier.height(24.dp))
        SectionLabel("Step 1 · Export from your old app")
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SourceGuide(
                "Google Password Manager",
                "Open Google Password Manager (phone Settings → Google → Autofill → Google Password Manager, " +
                    "or passwords.google.com) → ⚙ Settings → Export passwords → Export. Save the .csv file.",
            )
            SourceGuide(
                "Chrome, Edge, Brave, Opera",
                "Open the browser → Settings → Password Manager (or Passwords) → ⚙ Settings → Export passwords. Save the .csv file.",
            )
            SourceGuide(
                "Samsung Pass, Bitwarden, 1Password, LastPass, Dashlane, Proton Pass, Firefox, KeePass",
                "Use the app's Export or Backup option and choose CSV (unencrypted). On some apps this is only " +
                    "available in the desktop or web version.",
            )
        }

        Spacer(Modifier.height(24.dp))
        SectionLabel("Step 2 · Import into VaultX")
        if (busy) {
            NeuCard(Modifier.fillMaxWidth(), inset = true) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(24.dp), color = p.accent, strokeWidth = 3.dp)
                    Spacer(Modifier.width(14.dp))
                    Text("Importing and encrypting…", color = p.text)
                }
            }
        } else {
            AccentButton("Choose CSV file", pickFile, Modifier.fillMaxWidth(), icon = Icons.Outlined.Download)
        }

        AnimatedVisibility(result != null) {
            result?.let { r ->
                Column {
                    Spacer(Modifier.height(18.dp))
                    NeuCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(18.dp)) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.CheckCircle, null, tint = p.success)
                                Spacer(Modifier.width(10.dp))
                                Text("Import complete", color = p.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Spacer(Modifier.height(12.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Stat("${r.added}", "Added", p.success, Modifier.weight(1f))
                                Stat("${r.updated}", "Updated", p.accent, Modifier.weight(1f))
                                Stat("${r.skipped}", "Already saved", p.subText, Modifier.weight(1f))
                            }
                            Spacer(Modifier.height(14.dp))
                            Row {
                                Icon(Icons.Outlined.WarningAmber, null, tint = p.danger, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    "Delete the exported CSV file from your phone now — anyone who opens it can read your passwords.",
                                    color = p.subText, fontSize = 12.sp,
                                )
                            }
                        }
                    }
                }
            }
        }

        error?.let { msg ->
            Spacer(Modifier.height(18.dp))
            NeuCard(Modifier.fillMaxWidth(), inset = true) {
                Row {
                    Icon(Icons.Outlined.WarningAmber, null, tint = p.danger, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(12.dp))
                    Text(msg, color = p.danger, fontSize = 13.sp)
                }
            }
        }

        Spacer(Modifier.height(28.dp))
        SectionLabel("Backup")
        NeuButton(
            "Export all to CSV",
            {
                if (count == 0) Toast.makeText(ctx, "Your vault is empty", Toast.LENGTH_SHORT).show()
                else confirmExport = true
            },
            Modifier.fillMaxWidth(),
            icon = Icons.Outlined.Upload,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Use this to move VaultX to a new phone. The file works with Google, Chrome and most password managers.",
            color = p.subText, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 6.dp),
        )
        Spacer(Modifier.height(24.dp))
    }

    if (confirmExport) {
        AlertDialog(
            onDismissRequest = { confirmExport = false },
            title = { Text("Export $count passwords?") },
            text = {
                Text("The file will contain every password in plain text (not encrypted). Keep it somewhere safe and delete it after use.")
            },
            confirmButton = {
                TextButton(onClick = { confirmExport = false; startExport() }) { Text("Export", color = p.danger) }
            },
            dismissButton = { TextButton(onClick = { confirmExport = false }) { Text("Cancel") } },
            containerColor = p.bg,
        )
    }
}

@Composable
private fun SourceGuide(title: String, steps: String) {
    val p = Neu.colors
    var open by remember { mutableStateOf(false) }
    NeuCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(16.dp), onClick = { open = !open }) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Icon(if (open) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore, null, tint = p.subText)
            }
            AnimatedVisibility(open) {
                Text(steps, color = p.subText, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
            }
        }
    }
}

@Composable
private fun Stat(value: String, label: String, color: Color, modifier: Modifier) {
    val p = Neu.colors
    Column(
        modifier.neu(p, radius = 14.dp, elevation = 4.dp, inset = true).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(label, color = p.subText, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}
