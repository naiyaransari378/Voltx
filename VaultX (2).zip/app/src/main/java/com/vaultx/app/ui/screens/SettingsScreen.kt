package com.vaultx.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vaultx.app.BuildConfig
import com.vaultx.app.Session
import com.vaultx.app.data.Prefs
import com.vaultx.app.ui.components.AccentButton
import com.vaultx.app.ui.components.NeuButton
import com.vaultx.app.ui.components.NeuCard
import com.vaultx.app.ui.components.SectionLabel
import com.vaultx.app.ui.components.SettingSwitch
import com.vaultx.app.ui.components.TopBar
import com.vaultx.app.ui.theme.Neu
import com.vaultx.app.ui.theme.neu
import com.vaultx.app.util.AutofillHelper

@Composable
fun SettingsScreen(onBack: () -> Unit, onLock: () -> Unit, onImport: () -> Unit) {
    val p = Neu.colors
    val ctx = LocalContext.current
    val tick = Session.resumeTick
    val autofillOn = remember(tick) { AutofillHelper.isEnabled(ctx) }
    var autoSave by remember { mutableStateOf(Prefs.autoSave(ctx)) }
    var autoLock by remember { mutableStateOf(Prefs.autoLock(ctx)) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
    ) {
        TopBar("Settings", onBack)
        Spacer(Modifier.height(24.dp))

        SectionLabel("Autofill")
        NeuCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(18.dp)) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).neu(p, elevation = 4.dp, inset = true, circle = true), contentAlignment = Alignment.Center) {
                        Box(
                            Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(if (autofillOn) p.success else p.danger),
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Autofill service", color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(
                            if (autofillOn) "VaultX is filling & saving passwords" else "Not enabled",
                            color = p.subText, fontSize = 12.sp,
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                if (autofillOn) {
                    NeuButton("Open system settings", { AutofillHelper.openSettings(ctx) }, Modifier.fillMaxWidth())
                } else {
                    AccentButton("Enable VaultX autofill", { AutofillHelper.openSettings(ctx) }, Modifier.fillMaxWidth())
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        SettingSwitch(
            Icons.Outlined.AutoAwesome, "Auto-save new logins",
            "Offer to save passwords you type in other apps & sites", autoSave,
        ) { autoSave = it; Prefs.setAutoSave(ctx, it) }

        Spacer(Modifier.height(24.dp))
        SectionLabel("Security")
        SettingSwitch(
            Icons.Outlined.Lock, "Auto-lock", "Lock the vault whenever you leave the app", autoLock,
        ) { autoLock = it; Prefs.setAutoLock(ctx, it) }
        Spacer(Modifier.height(16.dp))
        NeuButton("Lock now", onLock, Modifier.fillMaxWidth(), icon = Icons.Outlined.Lock)

        Spacer(Modifier.height(24.dp))
        SectionLabel("Import & export")
        NeuButton("Import from other apps", onImport, Modifier.fillMaxWidth(), icon = Icons.Outlined.Download)

        Spacer(Modifier.height(24.dp))
        SectionLabel("Good to know")
        NeuCard(Modifier.fillMaxWidth(), inset = true, contentPadding = PaddingValues(18.dp)) {
            Column {
                Tip(Icons.Outlined.Shield, "Everything is encrypted with AES-256-GCM using a key locked in the Android Keystore. Nothing leaves your phone.")
                Spacer(Modifier.height(14.dp))
                Tip(Icons.Outlined.Info, "Chrome: Settings → Autofill services → “Autofill using another service”, then restart Chrome.")
                Spacer(Modifier.height(14.dp))
                Tip(Icons.Outlined.Lock, "Filling a password always asks for your fingerprint, face or screen lock first.")
            }
        }
        Spacer(Modifier.height(24.dp))
        Text(
            "VaultX ${BuildConfig.VERSION_NAME}",
            color = p.subText, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally),
        )
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun Tip(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    val p = Neu.colors
    Row {
        Icon(icon, null, tint = p.accent, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(12.dp))
        Text(text, color = p.subText, fontSize = 13.sp)
    }
}
