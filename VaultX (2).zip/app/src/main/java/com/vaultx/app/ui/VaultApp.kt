package com.vaultx.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.vaultx.app.Session
import com.vaultx.app.ui.screens.DetailScreen
import com.vaultx.app.ui.screens.EditScreen
import com.vaultx.app.ui.screens.HomeScreen
import com.vaultx.app.ui.screens.ImportScreen
import com.vaultx.app.ui.screens.LockScreen
import com.vaultx.app.ui.screens.SettingsScreen
import com.vaultx.app.ui.theme.Neu

sealed interface Route {
    data object Home : Route
    data class Detail(val id: String) : Route
    data class Edit(val id: String?) : Route
    data object Settings : Route
    data object Import : Route
}

@Composable
fun VaultApp(onUnlock: () -> Unit, onLock: () -> Unit) {
    val p = Neu.colors
    Box(
        Modifier
            .fillMaxSize()
            .background(p.bg)
            .systemBarsPadding()
            .imePadding(),
    ) {
        if (!Session.unlocked) {
            LockScreen(onUnlock)
        } else {
            val stack = Session.stack
            val route = stack.lastOrNull() ?: Route.Home
            val push: (Route) -> Unit = { stack.add(it) }
            val pop: () -> Unit = { if (stack.size > 1) stack.removeAt(stack.lastIndex) }

            BackHandler(enabled = stack.size > 1) { pop() }

            AnimatedContent(
                targetState = route,
                transitionSpec = {
                    (fadeIn(tween(220)) + slideInHorizontally(tween(260)) { it / 10 }) togetherWith fadeOut(tween(150))
                },
                label = "nav",
            ) { r ->
                when (r) {
                    Route.Home -> HomeScreen(
                        onOpen = { push(Route.Detail(it)) },
                        onAdd = { push(Route.Edit(null)) },
                        onSettings = { push(Route.Settings) },
                        onImport = { push(Route.Import) },
                    )
                    is Route.Detail -> DetailScreen(r.id, onBack = pop, onEdit = { push(Route.Edit(r.id)) })
                    is Route.Edit -> EditScreen(r.id, onBack = pop)
                    Route.Settings -> SettingsScreen(onBack = pop, onLock = onLock, onImport = { push(Route.Import) })
                    Route.Import -> ImportScreen(onBack = pop)
                }
            }
        }
    }
}
