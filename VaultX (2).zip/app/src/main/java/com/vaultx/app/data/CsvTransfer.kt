package com.vaultx.app.data

/**
 * Reads CSV exports from other password managers and writes VaultX backups.
 * Supported: Google Password Manager, Chrome, Edge, Brave, Opera, Samsung Internet, Firefox,
 * Bitwarden, 1Password, LastPass, Dashlane, Proton Pass, KeePass and most generic CSV files.
 */
object CsvTransfer {
    class ParseException(message: String) : Exception(message)

    private val TITLE_COLS = listOf("name", "title", "account", "item name", "label", "entry")
    private val URL_COLS = listOf("url", "login_uri", "website", "web site", "uri", "login url", "hostname", "origin_url", "web address", "urls")
    private val USER_COLS = listOf("username", "login_username", "user name", "user", "login", "email", "e-mail", "username1", "login name")
    private val PASS_COLS = listOf("password", "login_password", "pass", "passwd", "pwd")
    private val NOTE_COLS = listOf("note", "notes", "extra", "comments", "comment")

    fun parse(raw: String): List<Credential> {
        val text = raw.removePrefix("\uFEFF")
        val firstLine = text.lineSequence().firstOrNull().orEmpty()
        val delimiter = when {
            firstLine.count { it == '\t' } > firstLine.count { it == ',' } -> '\t'
            firstLine.count { it == ';' } > firstLine.count { it == ',' } -> ';'
            else -> ','
        }
        val rows = parseRows(text, delimiter)
        if (rows.isEmpty()) throw ParseException("The file is empty.")

        val header = rows.first().map { it.trim().trim('"').lowercase() }
        fun col(names: List<String>): Int {
            for (n in names) {
                val i = header.indexOf(n)
                if (i >= 0) return i
            }
            return -1
        }

        val iPass = col(PASS_COLS)
        if (iPass < 0) {
            throw ParseException("No password column found. Export your passwords as a CSV file and try again.")
        }
        val iTitle = col(TITLE_COLS)
        val iUrl = col(URL_COLS)
        val iUser = col(USER_COLS)
        val iNotes = col(NOTE_COLS)
        val now = System.currentTimeMillis()

        return rows.drop(1).mapNotNull { r ->
            val password = r.getOrNull(iPass).orEmpty()
            if (password.isBlank()) return@mapNotNull null
            val target = cleanTarget(r.getOrNull(iUrl).orEmpty())
            val title = r.getOrNull(iTitle).orEmpty().trim()
                .ifBlank { target }
                .ifBlank { "Imported login" }
            Credential(
                title = title,
                username = r.getOrNull(iUser).orEmpty().trim(),
                password = password,
                target = target,
                notes = r.getOrNull(iNotes).orEmpty().trim(),
                createdAt = now,
                updatedAt = now,
            )
        }
    }

    /** "https://www.site.com/login" → "site.com", "android://hash@com.app.id/" → "com.app.id" */
    fun cleanTarget(url: String): String {
        val u = url.trim()
        if (u.isEmpty()) return ""
        if (u.startsWith("android://", ignoreCase = true)) {
            return u.substringAfter('@').substringBefore('/').trim()
        }
        // Some managers store several URLs separated by commas or spaces – keep the first.
        val first = u.split(',', ' ', '\n').firstOrNull { it.isNotBlank() } ?: u
        return Vault.normalize(first)
    }

    fun toCsv(items: List<Credential>): String = buildString {
        append("name,url,username,password,note\n")
        items.forEach { c ->
            append(listOf(c.title, c.target, c.username, c.password, c.notes).joinToString(",") { escape(it) })
            append('\n')
        }
    }

    private fun escape(v: String): String =
        if (v.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"" + v.replace("\"", "\"\"") + "\"" else v

    private fun parseRows(text: String, d: Char): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        val field = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (inQuotes) {
                if (ch == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') {
                        field.append('"'); i++
                    } else {
                        inQuotes = false
                    }
                } else {
                    field.append(ch)
                }
            } else {
                when (ch) {
                    '"' -> inQuotes = true
                    d -> { row.add(field.toString()); field.setLength(0) }
                    '\r' -> Unit
                    '\n' -> {
                        row.add(field.toString()); field.setLength(0)
                        if (row.any { it.isNotBlank() }) rows.add(row)
                        row = mutableListOf()
                    }
                    else -> field.append(ch)
                }
            }
            i++
        }
        row.add(field.toString())
        if (row.any { it.isNotBlank() }) rows.add(row)
        return rows
    }
}
