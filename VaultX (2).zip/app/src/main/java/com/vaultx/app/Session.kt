package com.vaultx.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.vaultx.app.ui.Route

/** In-memory session state. Cleared when the process dies, so the vault always starts locked. */
object Session {
    var unlocked by mutableStateOf(false)
    var resumeTick by mutableIntStateOf(0)

    /** True while VaultX itself opens a system screen (file picker, confirm lock) so it doesn't auto-lock. */
    @Volatile var suppressAutoLock = false
    val stack = mutableStateListOf<Route>(Route.Home)

    fun lock() {
        unlocked = false
        stack.clear()
        stack.add(Route.Home)
    }
}
